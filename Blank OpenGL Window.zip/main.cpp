#include <iostream>
#include <GLFW/glfw3.h>
using namespace std;

int main(void)
{
    if (!glfwInit()) return -1;

    GLFWwindow* window;

    window = glfwCreateWindow(500, 200, "Window 1", NULL, NULL);

    while (window != NULL)
    {
        if (glfwWindowShouldClose(window))
        {
            glfwDestroyWindow(window);
            window = nullptr;
        }
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}